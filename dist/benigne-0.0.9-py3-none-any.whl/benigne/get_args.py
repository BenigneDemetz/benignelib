def get_args() -> list:
    """Get command line arguments.
    Return a list."""
    import sys
    
    return sys.argv[1:]
