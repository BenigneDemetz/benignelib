# Benigne

Personnal features library.

## Installation

```bash
pip install benigne
```

## Usage

TODO: Add usage examples

## License

MIT